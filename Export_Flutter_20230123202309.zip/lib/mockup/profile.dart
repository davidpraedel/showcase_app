import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // profilekn1 (5:207)
        width: double.infinity,
        height: 844*fem,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff323232)),
          color: Color(0xff000000),
          borderRadius: BorderRadius.circular(45*fem),
          boxShadow: [
            BoxShadow(
              color: Color(0x3f000000),
              offset: Offset(0*fem, 4*fem),
              blurRadius: 2*fem,
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              // addsquarelightNKX (5:208)
              left: 35.375*fem,
              top: 36.375*fem,
              child: Align(
                child: SizedBox(
                  width: 20.25*fem,
                  height: 20.25*fem,
                  child: Image.asset(
                    'assets/mockup/images/addsquarelight-vi9.png',
                    width: 20.25*fem,
                    height: 20.25*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupcre9zLu (LYzkxsmQ9DN1NmWbT5cre9)
              left: 47*fem,
              top: 82.6666641235*fem,
              child: Container(
                width: 291*fem,
                height: 50*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // followereRT (5:233)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.67*fem, 0*fem, 0*fem),
                      constraints: BoxConstraints (
                        maxWidth: 82*fem,
                      ),
                      child: Text(
                        'Dir folgen\n120 ',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w800,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 41*fem,
                    ),
                    Container(
                      // usercicrlelightPXT (5:241)
                      width: 50*fem,
                      height: double.infinity,
                      child: Stack(
                        children: [
                          Positioned(
                            // ellipse46uEu (I5:241;4:32)
                            left: 18.75*fem,
                            top: 12.9166717529*fem,
                            child: Align(
                              child: SizedBox(
                                width: 12.5*fem,
                                height: 12.5*fem,
                                child: Image.asset(
                                  'assets/mockup/images/ellipse-46.png',
                                  width: 12.5*fem,
                                  height: 12.5*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse47B5w (I5:241;4:33)
                            left: 6.25*fem,
                            top: 4.5833358765*fem,
                            child: Align(
                              child: SizedBox(
                                width: 37.5*fem,
                                height: 37.5*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(18.75*fem),
                                    border: Border.all(color: Color(0xffffffff)),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse48D2d (I5:241;4:34)
                            left: 12.5*fem,
                            top: 29.5833358765*fem,
                            child: Align(
                              child: SizedBox(
                                width: 25*fem,
                                height: 7.72*fem,
                                child: Image.asset(
                                  'assets/mockup/images/ellipse-48-WFo.png',
                                  width: 25*fem,
                                  height: 7.72*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // abiturbild1Fk1 (I5:241;4:54)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 50*fem,
                                height: 50*fem,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(90*fem),
                                  child: Image.asset(
                                    'assets/mockup/images/abitur-bild-1.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 41*fem,
                    ),
                    Container(
                      // followingg4d (5:234)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.67*fem, 0*fem, 0*fem),
                      constraints: BoxConstraints (
                        maxWidth: 77*fem,
                      ),
                      child: Text(
                        'Du folgst\n300',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w800,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupkg5b7Qq (LYzmc7CMzLN9bK3w7JKG5b)
              left: 0*fem,
              top: 172*fem,
              child: Container(
                width: 857*fem,
                height: 574*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // followingA8D (5:246)
                      left: 235*fem,
                      top: 322*fem,
                      child: Align(
                        child: SizedBox(
                          width: 129*fem,
                          height: 42*fem,
                          child: Text(
                            'Städte besucht\n200',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w800,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // followingNzy (5:247)
                      left: 19*fem,
                      top: 322*fem,
                      child: Align(
                        child: SizedBox(
                          width: 132*fem,
                          height: 42*fem,
                          child: Text(
                            'Länder besucht\n30',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w800,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // line2b73 (5:235)
                      left: 26*fem,
                      top: 382*fem,
                      child: Align(
                        child: SizedBox(
                          width: 332*fem,
                          height: 1*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xff646464),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // ellipse50FhP (5:236)
                      left: 48*fem,
                      top: 429*fem,
                      child: Align(
                        child: SizedBox(
                          width: 7*fem,
                          height: 7*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(3.5*fem),
                              color: Color(0xffd9d9d9),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // ellipse517jb (5:237)
                      left: 48*fem,
                      top: 567*fem,
                      child: Align(
                        child: SizedBox(
                          width: 7*fem,
                          height: 7*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(3.5*fem),
                              color: Color(0xffd9d9d9),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // line3bPs (5:238)
                      left: 51*fem,
                      top: 433*fem,
                      child: Align(
                        child: SizedBox(
                          width: 1*fem,
                          height: 136*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // HGh (5:239)
                      left: 15*fem,
                      top: 402*fem,
                      child: Align(
                        child: SizedBox(
                          width: 71*fem,
                          height: 16*fem,
                          child: Text(
                            '23.01.2022',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 13*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // screenshot202301221645441Wv9 (5:248)
                      left: 45*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 300*fem,
                          height: 300*fem,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(200*fem),
                            child: Image.asset(
                              'assets/mockup/images/screenshot-2023-01-22-164544-1.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // dieserstdtetripwar8109y7 (5:256)
                      left: 117*fem,
                      top: 402*fem,
                      child: Align(
                        child: SizedBox(
                          width: 166*fem,
                          height: 16*fem,
                          child: RichText(
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                              children: [
                                TextSpan(
                                  text: 'Dieser',
                                ),
                                TextSpan(
                                  text: ' ',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: 'Städtetrip',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: ' war ',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: '8/10',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff41732a),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // grouplightVDf (8:258)
                      left: 112.8624267578*fem,
                      top: 439.2083435059*fem,
                      child: Align(
                        child: SizedBox(
                          width: 15.28*fem,
                          height: 14.06*fem,
                          child: Image.asset(
                            'assets/mockup/images/grouplight-sRX.png',
                            width: 15.28*fem,
                            height: 14.06*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // luislohnerje791KTb (8:259)
                      left: 152*fem,
                      top: 439*fem,
                      child: Align(
                        child: SizedBox(
                          width: 120*fem,
                          height: 15*fem,
                          child: Text(
                            'Luis.Lohner, JE79, +1',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // wUy (8:260)
                      left: 153*fem,
                      top: 475*fem,
                      child: Align(
                        child: SizedBox(
                          width: 138*fem,
                          height: 15*fem,
                          child: Text(
                            '20.01.2022 - 23.01.2022',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // europadeutschlandhamburgmyo (8:261)
                      left: 153*fem,
                      top: 511*fem,
                      child: Align(
                        child: SizedBox(
                          width: 177*fem,
                          height: 15*fem,
                          child: Text(
                            'Europa, Deutschland, Hamburg',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // lovepeacehappinessmarteriabxq (8:262)
                      left: 153*fem,
                      top: 547*fem,
                      child: Align(
                        child: SizedBox(
                          width: 198*fem,
                          height: 15*fem,
                          child: Text(
                            'Love, Peace & Happiness, Marteria',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // pinaltlightded (8:263)
                      left: 0*fem,
                      top: 27*fem,
                      child: Align(
                        child: SizedBox(
                          width: 622.35*fem,
                          height: 501.4*fem,
                          child: Image.asset(
                            'assets/mockup/images/pinaltlight-sS5.png',
                            width: 622.35*fem,
                            height: 501.4*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // daterangelight4V3 (8:264)
                      left: 111.125*fem,
                      top: 473.125*fem,
                      child: Align(
                        child: SizedBox(
                          width: 18.75*fem,
                          height: 18.75*fem,
                          child: Image.asset(
                            'assets/mockup/images/daterangelight.png',
                            width: 18.75*fem,
                            height: 18.75*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // musiclightbdP (8:265)
                      left: 111.1666870117*fem,
                      top: 546.1666870117*fem,
                      child: Align(
                        child: SizedBox(
                          width: 15.63*fem,
                          height: 17.71*fem,
                          child: Image.asset(
                            'assets/mockup/images/musiclight.png',
                            width: 15.63*fem,
                            height: 17.71*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupjsnh3VP (LYznHAuc5YuJrwPT5VJSnh)
              left: 15*fem,
              top: 753*fem,
              child: Container(
                width: 296*fem,
                height: 18.88*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // JgD (5:240)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26.17*fem, 2.88*fem),
                      child: Text(
                        '20.01.2022',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // booklightmJu (8:290)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.13*fem, 24.17*fem, 0*fem),
                      width: 16.67*fem,
                      height: 18.75*fem,
                      child: Image.asset(
                        'assets/mockup/images/booklight-m4R.png',
                        width: 16.67*fem,
                        height: 18.75*fem,
                      ),
                    ),
                    Container(
                      // wochenendemitderfamilypHB (8:289)
                      margin: EdgeInsets.fromLTRB(0*fem, 2.13*fem, 0*fem, 0*fem),
                      child: Text(
                        'Wochenende mit der Family',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // currentscreensWM (4:30)
              left: 297*fem,
              top: 837*fem,
              child: Align(
                child: SizedBox(
                  width: 20*fem,
                  height: 2*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // settinglinelightXL1 (5:209)
              left: 333.25*fem,
              top: 35.25*fem,
              child: Align(
                child: SizedBox(
                  width: 22.5*fem,
                  height: 22.5*fem,
                  child: Image.asset(
                    'assets/mockup/images/settinglinelight.png',
                    width: 22.5*fem,
                    height: 22.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // separatornavigationB9f (5:210)
              left: 45*fem,
              top: 780*fem,
              child: Align(
                child: SizedBox(
                  width: 300*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff3c3c3c),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // mapdXT (5:211)
              left: 182.5*fem,
              top: 801.1666870117*fem,
              child: Align(
                child: SizedBox(
                  width: 25*fem,
                  height: 20*fem,
                  child: Image.asset(
                    'assets/mockup/images/map-qu7.png',
                    width: 25*fem,
                    height: 20*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // homelight6A9 (5:212)
              left: 70.3333129883*fem,
              top: 800.2520751953*fem,
              child: Align(
                child: SizedBox(
                  width: 23.33*fem,
                  height: 26.75*fem,
                  child: Image.asset(
                    'assets/mockup/images/homelight.png',
                    width: 23.33*fem,
                    height: 26.75*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // useraltlightkVb (5:214)
              left: 294.5*fem,
              top: 798.6666870117*fem,
              child: Align(
                child: SizedBox(
                  width: 25*fem,
                  height: 25.83*fem,
                  child: Image.asset(
                    'assets/mockup/images/useraltlight-SCd.png',
                    width: 25*fem,
                    height: 25.83*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // showcasecXo (5:215)
              left: 136*fem,
              top: 32*fem,
              child: Align(
                child: SizedBox(
                  width: 118*fem,
                  height: 28*fem,
                  child: Text(
                    'Showcase',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 23*ffem,
                      fontWeight: FontWeight.w800,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}