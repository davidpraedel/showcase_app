import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // userFW5 (2:4)
        width: double.infinity,
        height: 844*fem,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff323232)),
          color: Color(0xff000000),
          borderRadius: BorderRadius.circular(45*fem),
          boxShadow: [
            BoxShadow(
              color: Color(0x3f000000),
              offset: Offset(0*fem, 4*fem),
              blurRadius: 2*fem,
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              // addsquarelightGAH (5:78)
              left: 32*fem,
              top: 33*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 27*fem,
                  child: Image.asset(
                    'assets/mockup/images/addsquarelight-h3B.png',
                    width: 27*fem,
                    height: 27*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupgdiuJcm (LYzoHyYxRXFFkQknqdgDiu)
              left: 19*fem,
              top: 89*fem,
              child: Container(
                width: 165*fem,
                height: 50*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // profilepictureyiu (5:249)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                      width: 50*fem,
                      height: 50*fem,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(90*fem),
                        child: Image.asset(
                          'assets/mockup/images/profilepicture.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    Container(
                      // usernameqWD (5:253)
                      margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                      child: Text(
                        'Luis.Lohner',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w800,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupzivztjP (LYzoT48AMYJfRQnrTwZivZ)
              left: 17*fem,
              top: 494*fem,
              child: Container(
                width: 355*fem,
                height: 42*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // followinga6R (5:251)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 94*fem, 0*fem),
                      constraints: BoxConstraints (
                        maxWidth: 132*fem,
                      ),
                      child: Text(
                        'Länder besucht\n102',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w800,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // followingRcq (5:252)
                      constraints: BoxConstraints (
                        maxWidth: 129*fem,
                      ),
                      child: Text(
                        'Städte besucht\n508',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w800,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // line4Vsb (5:254)
              left: 29*fem,
              top: 554*fem,
              child: Align(
                child: SizedBox(
                  width: 332*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff646464),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // screenshot202301221705331n61 (5:255)
              left: 45*fem,
              top: 172*fem,
              child: Align(
                child: SizedBox(
                  width: 299.18*fem,
                  height: 300*fem,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(200*fem),
                    child: Image.asset(
                      'assets/mockup/images/screenshot-2023-01-22-170533-1.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // settinglinelight1zM (4:21)
              left: 331*fem,
              top: 33*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 27*fem,
                  child: Image.asset(
                    'assets/mockup/images/settinglinelight-Wdj.png',
                    width: 27*fem,
                    height: 27*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // separatornavigationV8q (4:20)
              left: 45*fem,
              top: 780*fem,
              child: Align(
                child: SizedBox(
                  width: 300*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff3c3c3c),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // mapMRw (4:16)
              left: 175*fem,
              top: 792*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 40*fem,
                  child: Image.asset(
                    'assets/mockup/images/map.png',
                    width: 40*fem,
                    height: 40*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // homelightDU9 (4:5)
              left: 62*fem,
              top: 792*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 40*fem,
                  child: Image.asset(
                    'assets/mockup/images/homelight-fA5.png',
                    width: 40*fem,
                    height: 40*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // useraltlightUey (4:2)
              left: 287*fem,
              top: 792*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 40*fem,
                  child: Image.asset(
                    'assets/mockup/images/useraltlight.png',
                    width: 40*fem,
                    height: 40*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // showcasewoT (3:3)
              left: 136*fem,
              top: 32*fem,
              child: Align(
                child: SizedBox(
                  width: 118*fem,
                  height: 28*fem,
                  child: Text(
                    'Showcase',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 23*ffem,
                      fontWeight: FontWeight.w800,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}