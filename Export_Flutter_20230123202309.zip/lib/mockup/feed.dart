import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // feedvry (5:82)
        width: double.infinity,
        height: 844*fem,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff323232)),
          color: Color(0xff000000),
          borderRadius: BorderRadius.circular(45*fem),
          boxShadow: [
            BoxShadow(
              color: Color(0x3f000000),
              offset: Offset(0*fem, 4*fem),
              blurRadius: 2*fem,
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupzgxw9Uq (LYzpVMj1omitzKB4qszgXw)
              left: 15*fem,
              top: 86*fem,
              child: Container(
                width: 270*fem,
                height: 30*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // usercicrlelightcdK (5:83)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                      width: 30*fem,
                      height: double.infinity,
                      child: Stack(
                        children: [
                          Positioned(
                            // ellipse46JW9 (I5:83;4:32)
                            left: 11.25*fem,
                            top: 7.75*fem,
                            child: Align(
                              child: SizedBox(
                                width: 7.5*fem,
                                height: 7.5*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(3.75*fem),
                                    border: Border.all(color: Color(0xffffffff)),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse47MDX (I5:83;4:33)
                            left: 3.75*fem,
                            top: 2.75*fem,
                            child: Align(
                              child: SizedBox(
                                width: 22.5*fem,
                                height: 22.5*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(11.25*fem),
                                    border: Border.all(color: Color(0xffffffff)),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse48DWd (I5:83;4:34)
                            left: 7.5*fem,
                            top: 17.75*fem,
                            child: Align(
                              child: SizedBox(
                                width: 15*fem,
                                height: 4.63*fem,
                                child: Image.asset(
                                  'assets/mockup/images/ellipse-48.png',
                                  width: 15*fem,
                                  height: 4.63*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // abiturbild1HFb (I5:83;4:54)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 30*fem,
                                height: 30*fem,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(90*fem),
                                  child: Image.asset(
                                    'assets/mockup/images/abitur-bild-1-gqB.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // manuelsletzterstdtetripwar810k (5:85)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                      child: RichText(
                        text: TextSpan(
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 13*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2102272327*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                          children: [
                            TextSpan(
                              text: 'Manuel’s letzter ',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                            TextSpan(
                              text: 'Städtetrip',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                            TextSpan(
                              text: ' war ',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                            TextSpan(
                              text: '8/10',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff41732a),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupfd5oNbo (LYzpumC1xDyuqH9ALJfd5o)
              left: 22.8623962402*fem,
              top: 131*fem,
              child: Container(
                width: 159.14*fem,
                height: 15*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // grouplight2gM (5:84)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23.86*fem, 0.52*fem),
                      width: 15.28*fem,
                      height: 14.06*fem,
                      child: Image.asset(
                        'assets/mockup/images/grouplight.png',
                        width: 15.28*fem,
                        height: 14.06*fem,
                      ),
                    ),
                    Text(
                      // luislohnerje791HMP (5:89)
                      'Luis.Lohner, JE79, +1',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupevndPfK (LYzqSQycP6P8BD1E4YEVnD)
              left: 15*fem,
              top: 199*fem,
              child: Container(
                width: 356*fem,
                height: 507.4*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // 3js (5:86)
                      left: 179*fem,
                      top: 266*fem,
                      child: Align(
                        child: SizedBox(
                          width: 33.13*fem,
                          height: 70*fem,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10*fem),
                            child: Image.asset(
                              'assets/mockup/images/.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // UqB (5:87)
                      left: 47*fem,
                      top: 215*fem,
                      child: Align(
                        child: SizedBox(
                          width: 77*fem,
                          height: 121*fem,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10*fem),
                            child: Image.asset(
                              'assets/mockup/images/-FF3.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // wTs (5:88)
                      left: 135*fem,
                      top: 266*fem,
                      child: Align(
                        child: SizedBox(
                          width: 33.13*fem,
                          height: 70*fem,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10*fem),
                            child: Image.asset(
                              'assets/mockup/images/-bsb.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // europadeutschlandhamburgPKs (5:91)
                      left: 48*fem,
                      top: 4*fem,
                      child: Align(
                        child: SizedBox(
                          width: 177*fem,
                          height: 15*fem,
                          child: Text(
                            'Europa, Deutschland, Hamburg',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // lovepeacehappinessmarteriaRnM (5:92)
                      left: 48*fem,
                      top: 40*fem,
                      child: Align(
                        child: SizedBox(
                          width: 198*fem,
                          height: 15*fem,
                          child: Text(
                            'Love, Peace & Happiness, Marteria',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // wochenendemitderfamilyqLH (5:93)
                      left: 48*fem,
                      top: 77*fem,
                      child: Align(
                        child: SizedBox(
                          width: 158*fem,
                          height: 15*fem,
                          child: Text(
                            'Wochenende mit der Family',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // loremipsumdolorsitametconsetet (5:94)
                      left: 47*fem,
                      top: 104*fem,
                      child: Align(
                        child: SizedBox(
                          width: 287*fem,
                          height: 88*fem,
                          child: RichText(
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                              children: [
                                TextSpan(
                                  text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum ',
                                ),
                                TextSpan(
                                  text: 'Mehr',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1.2125*ffem/fem,
                                    decoration: TextDecoration.underline,
                                    color: Color(0xffffffff),
                                    decorationColor: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // pinaltlightaMj (5:95)
                      left: 6.6458435059*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 349.35*fem,
                          height: 21.4*fem,
                          child: Image.asset(
                            'assets/mockup/images/pinaltlight-BSu.png',
                            width: 349.35*fem,
                            height: 21.4*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // booklightp1B (5:96)
                      left: 7.1666564941*fem,
                      top: 74.125*fem,
                      child: Align(
                        child: SizedBox(
                          width: 16.67*fem,
                          height: 18.75*fem,
                          child: Image.asset(
                            'assets/mockup/images/booklight-CW1.png',
                            width: 16.67*fem,
                            height: 18.75*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // imgboxlight4w7 (5:97)
                      left: 8.125*fem,
                      top: 218.125*fem,
                      child: Align(
                        child: SizedBox(
                          width: 18.75*fem,
                          height: 18.75*fem,
                          child: Image.asset(
                            'assets/mockup/images/imgboxlight.png',
                            width: 18.75*fem,
                            height: 18.75*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // line1wED (5:98)
                      left: 14*fem,
                      top: 355*fem,
                      child: Align(
                        child: SizedBox(
                          width: 332*fem,
                          height: 1*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xff646464),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // grouplightp37 (5:100)
                      left: 7.8623962402*fem,
                      top: 418.2083435059*fem,
                      child: Align(
                        child: SizedBox(
                          width: 15.28*fem,
                          height: 14.06*fem,
                          child: Image.asset(
                            'assets/mockup/images/grouplight-Pyo.png',
                            width: 15.28*fem,
                            height: 14.06*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // luislohnersletzterurlaubwar210 (5:101)
                      left: 48*fem,
                      top: 378*fem,
                      child: Align(
                        child: SizedBox(
                          width: 226*fem,
                          height: 16*fem,
                          child: RichText(
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                              children: [
                                TextSpan(
                                  text: 'Luis.Lohner’s',
                                ),
                                TextSpan(
                                  text: ' letzter ',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: 'Urlaub',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: ' war ',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                                TextSpan(
                                  text: '2/10',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xffee0c0c),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // manuelkchli1BTK (5:102)
                      left: 47*fem,
                      top: 418*fem,
                      child: Align(
                        child: SizedBox(
                          width: 103*fem,
                          height: 15*fem,
                          child: Text(
                            'Manuel, Küchli, +1',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // Qay (5:103)
                      left: 48*fem,
                      top: 454*fem,
                      child: Align(
                        child: SizedBox(
                          width: 138*fem,
                          height: 15*fem,
                          child: Text(
                            '20.01.2022 - 23.01.2022',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // afrikabenin389 (5:104)
                      left: 48*fem,
                      top: 490*fem,
                      child: Align(
                        child: SizedBox(
                          width: 72*fem,
                          height: 15*fem,
                          child: Text(
                            'Afrika, Benin',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // pinaltlight6cD (5:107)
                      left: 6.6458435059*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 349.35*fem,
                          height: 507.4*fem,
                          child: Image.asset(
                            'assets/mockup/images/pinaltlight.png',
                            width: 349.35*fem,
                            height: 507.4*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // daterangelight9qP (5:109)
                      left: 6.125*fem,
                      top: 452.125*fem,
                      child: Align(
                        child: SizedBox(
                          width: 18.75*fem,
                          height: 18.75*fem,
                          child: Image.asset(
                            'assets/mockup/images/daterangelight-h8R.png',
                            width: 18.75*fem,
                            height: 18.75*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle4163ouw (5:110)
                      left: 223*fem,
                      top: 266*fem,
                      child: Align(
                        child: SizedBox(
                          width: 33.13*fem,
                          height: 70*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(10*fem),
                              border: Border.all(color: Color(0xff646464)),
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // dsci05181eff (5:111)
                      left: 0*fem,
                      top: 371*fem,
                      child: Align(
                        child: SizedBox(
                          width: 30*fem,
                          height: 30*fem,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(90*fem),
                            child: Image.asset(
                              'assets/mockup/images/dsci0518-1.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // 73T (5:112)
                      left: 229*fem,
                      top: 293*fem,
                      child: Align(
                        child: SizedBox(
                          width: 21*fem,
                          height: 15*fem,
                          child: Text(
                            '+10',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // musiclightNVB (5:113)
                      left: 6.1666564941*fem,
                      top: 39.1666679382*fem,
                      child: Align(
                        child: SizedBox(
                          width: 15.63*fem,
                          height: 17.71*fem,
                          child: Image.asset(
                            'assets/mockup/images/musiclight-qau.png',
                            width: 15.63*fem,
                            height: 17.71*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupai7fq7s (LYzq6RYvGxjHn88vVxAi7F)
              left: 21.125*fem,
              top: 165.125*fem,
              child: Container(
                width: 179.88*fem,
                height: 18.75*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // daterangelightWE1 (5:99)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23.13*fem, 0*fem),
                      width: 18.75*fem,
                      height: 18.75*fem,
                      child: Image.asset(
                        'assets/mockup/images/daterangelight-nAR.png',
                        width: 18.75*fem,
                        height: 18.75*fem,
                      ),
                    ),
                    Text(
                      // m9w (5:90)
                      '20.01.2022 - 23.01.2022',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupeqt1syf (LYzrB4RDg3NdxazGj8Eqt1)
              left: 22.1666564941*fem,
              top: 722.125*fem,
              child: Container(
                width: 99.83*fem,
                height: 18.75*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      // booklightm3T (5:108)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24.17*fem, 0*fem),
                      width: 16.67*fem,
                      height: 18.75*fem,
                      child: Image.asset(
                        'assets/mockup/images/booklight.png',
                        width: 16.67*fem,
                        height: 18.75*fem,
                      ),
                    ),
                    Container(
                      // suffurlaubESq (5:105)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.88*fem),
                      child: Text(
                        'Suffurlaub',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // loremipsumdolorsitametconsetet (5:106)
              left: 61*fem,
              top: 750*fem,
              child: Align(
                child: SizedBox(
                  width: 287*fem,
                  height: 30*fem,
                  child: Text(
                    'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut ',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // addsquarelightWof (5:114)
              left: 35.375*fem,
              top: 36.375*fem,
              child: Align(
                child: SizedBox(
                  width: 20.25*fem,
                  height: 20.25*fem,
                  child: Image.asset(
                    'assets/mockup/images/addsquarelight.png',
                    width: 20.25*fem,
                    height: 20.25*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // settinglinelightBeu (5:115)
              left: 333.2500038147*fem,
              top: 35.25*fem,
              child: Align(
                child: SizedBox(
                  width: 22.5*fem,
                  height: 22.5*fem,
                  child: Image.asset(
                    'assets/mockup/images/settinglinelight-Cxu.png',
                    width: 22.5*fem,
                    height: 22.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // separatornavigationeoP (5:116)
              left: 45*fem,
              top: 780*fem,
              child: Align(
                child: SizedBox(
                  width: 300*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff3c3c3c),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // map7gy (5:117)
              left: 182.5*fem,
              top: 801.1666870117*fem,
              child: Align(
                child: SizedBox(
                  width: 25*fem,
                  height: 20*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/mockup/images/map-ty3.png',
                      width: 25*fem,
                      height: 20*fem,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // homelightJmT (5:118)
              left: 70.3333435059*fem,
              top: 800.2520751953*fem,
              child: Align(
                child: SizedBox(
                  width: 23.33*fem,
                  height: 26.75*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/mockup/images/homelight-epm.png',
                      width: 23.33*fem,
                      height: 26.75*fem,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // currentscreenWsX (5:119)
              left: 72*fem,
              top: 837*fem,
              child: Align(
                child: SizedBox(
                  width: 20*fem,
                  height: 2*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // useraltlightnKF (5:120)
              left: 294.5*fem,
              top: 798.6666870117*fem,
              child: Align(
                child: SizedBox(
                  width: 25*fem,
                  height: 25.83*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/mockup/images/useraltlight-znq.png',
                      width: 25*fem,
                      height: 25.83*fem,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // showcasepWq (5:121)
              left: 136*fem,
              top: 32*fem,
              child: Align(
                child: SizedBox(
                  width: 118*fem,
                  height: 28*fem,
                  child: Text(
                    'Showcase',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 23*ffem,
                      fontWeight: FontWeight.w800,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}